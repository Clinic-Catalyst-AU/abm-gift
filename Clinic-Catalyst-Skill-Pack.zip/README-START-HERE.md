# Your Clinic Catalyst Skill Pack - start here

Three Claude skills plus a bonus, built for clinic owners, that you install once and use every
week. They run inside Claude Desktop (or claude.ai in your browser) - no coding, no terminal,
nothing technical.

Run them in this order the first time. It takes about 30 minutes and you only do it once.

1. *Clinic Voice Foundation* - Claude goes and reads how you already write (your website, your
   captions, your review replies), then asks you a handful of questions and writes your
   voice-foundation.md. This is the fix for "everything Claude writes sounds like every other clinic".
2. *Clinic Brand Guide* - turns your voice document plus a short questionnaire into brand-guide.md,
   the one file you paste into your Claude Project so every caption, email and page sounds like you.
3. *Clinic Hook Generator* - type a topic, get 5 scroll-stopping hooks scored for stopping power, in
   your voice, screened against AHPRA. Reels, captions, carousels, subject lines, landing pages.
4. *BONUS - Clinic Video Script* - tell it what the video is about and get a script you can film on
   your phone today: five hook options, the words to say, a no-talking-to-camera version, the
   on-screen text and the call to action. In your voice, screened against AHPRA.

## Install (about 2 minutes)

1. Open Claude Desktop (or claude.ai). Click your initials, then *Settings*, then *Capabilities*,
   and make sure *Code execution and file creation* is switched on.
2. Go to *Customize*, then *Skills*.
3. Click the *+* button, then *Create skill*, then *Upload a skill*, and choose
   `clinic-voice-foundation.zip`. Repeat for `clinic-brand-guide.zip`, `clinic-hook-generator.zip`
   and `clinic-video-script.zip`. Upload the zips exactly as they are - do not unzip them first.
4. Check each skill is toggled on in your skills list.
5. Start a new chat and type: *run the clinic voice foundation skill*. Claude takes it from there.

Tip: create a Claude Project named after your clinic first. When the skills hand you your voice
block and brand guide, paste them into that Project's instructions. Every chat inside the Project
then starts on-brand, automatically.

## What is in this folder

- `clinic-voice-foundation.zip`, `clinic-brand-guide.zip`, `clinic-hook-generator.zip`,
  `clinic-video-script.zip` - upload these.
- `skills/` - the same four skills as readable markdown, if you want to see exactly what each one
  tells Claude to do. Nothing hidden.

## Where this leads

These are four of the 30 skills every Clinic Catalyst clinic runs. The rest (ads, campaign build,
newsletter engine, reactivation, content engine, AI receptionist) get installed with you, in the
room, at the Fire Your Marketing Agency workshop, along with your CRM, follow-up ladder and
launched campaigns:
https://clinic-catalyst-au.github.io/fire-your-agency/

Or start with a free 30-minute Ads, Marketing and Systems session with Kelly and Alicia (valued at
$1,800). Real recommendations you can act on the same week, no pitch:
https://api.leadconnectorhq.com/widget/bookings/adsmarketingsystems

Kelly and Alicia x
Clinic Catalyst
